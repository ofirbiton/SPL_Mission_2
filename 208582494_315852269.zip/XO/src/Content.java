//Naim Moshe 315852269 & Ofir Biton 208582494
public enum Content {
    X,O,E
}
