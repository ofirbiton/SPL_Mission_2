//Naim Moshe 315852269 & Ofir Biton 208582494
package Race;
public class Track {
    private int finishRacers;
}
